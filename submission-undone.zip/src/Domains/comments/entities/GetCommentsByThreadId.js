class GetCommentsByThreadId {
  constructor(payload) {
    this._verifyPayload(payload);
    this.comments = payload;
  }

  _verifyPayload(payload) {
    if (!Array.isArray(payload)) {
      throw new Error('GET_COMMENTS.NOT_MEET_DATA_TYPE_SPECIFICATION');
    }

    if (payload.length > 0) {
      payload.forEach(({ id, username, date, content }) => {
        if (!id || !username || !date || !content) {
          throw new Error('GET_COMMENTS.NOT_CONTAIN_NEEDED_PROPERTY');
        }

        if (
          typeof id !== 'string' ||
          typeof username !== 'string' ||
          !date instanceof Date ||
          typeof content !== 'string'
        ) {
          throw new Error('GET_COMMENTS.NOT_MEET_DATA_TYPE_SPECIFICATION');
        }
      });
    }
  }
}

module.exports = GetCommentsByThreadId;
